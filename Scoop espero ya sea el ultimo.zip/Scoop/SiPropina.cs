﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Scoop
{
    public partial class SiPropina : Form
    {
        public SiPropina()
        {
            InitializeComponent();
        }

        private void button_Diezpor_Click(object sender, EventArgs e)
        {

        }

        private void button_Pagarprop_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Gracias por comprar en Scoop ", " Success! ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
