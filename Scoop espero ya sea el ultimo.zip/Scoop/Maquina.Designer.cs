﻿namespace Scoop
{
    partial class Maquina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_ElegirCookiesCream = new System.Windows.Forms.Button();
            this.button_ElegirGalleta = new System.Windows.Forms.Button();
            this.button_ElegirCoco = new System.Windows.Forms.Button();
            this.button_ElegirCaramelo = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.button_ElegirVinoTinto = new System.Windows.Forms.Button();
            this.button_ElegirPistache = new System.Windows.Forms.Button();
            this.button_ElegirDulceLeche = new System.Windows.Forms.Button();
            this.button_ElegirTaro = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.button_ElegirFresa = new System.Windows.Forms.Button();
            this.button_ElegirVainilla = new System.Windows.Forms.Button();
            this.button_ElegirChoc = new System.Windows.Forms.Button();
            this.button_ElegirLimon = new System.Windows.Forms.Button();
            this.Lab_digCookiesCream = new System.Windows.Forms.Label();
            this.Lab_digGalleta = new System.Windows.Forms.Label();
            this.Lab_digCoco = new System.Windows.Forms.Label();
            this.Lab_digCaramel = new System.Windows.Forms.Label();
            this.Lab_digVinoTinto = new System.Windows.Forms.Label();
            this.Lab_digPistache = new System.Windows.Forms.Label();
            this.Lab_digDulceLeche = new System.Windows.Forms.Label();
            this.Lab_digTaro = new System.Windows.Forms.Label();
            this.Lab_digFresa = new System.Windows.Forms.Label();
            this.Lab_digVainilla = new System.Windows.Forms.Label();
            this.Lab_digChoc = new System.Windows.Forms.Label();
            this.Lab_digLimon = new System.Windows.Forms.Label();
            this.Lab_CantLimon = new System.Windows.Forms.Label();
            this.Lab_PrecioCookiesCream = new System.Windows.Forms.Label();
            this.Lab_PrecioGalleta = new System.Windows.Forms.Label();
            this.Lab_PrecioCoco = new System.Windows.Forms.Label();
            this.Lab_PrecioCaramelo = new System.Windows.Forms.Label();
            this.Lab_PrecioVinoTinto = new System.Windows.Forms.Label();
            this.Lab_PrecioPistache = new System.Windows.Forms.Label();
            this.Lab_PrecioDulceLeche = new System.Windows.Forms.Label();
            this.Lab_PrecioTaro = new System.Windows.Forms.Label();
            this.Lab_PrecioFresa = new System.Windows.Forms.Label();
            this.Lab_PrecioVainilla = new System.Windows.Forms.Label();
            this.Lab_PrecioChoc = new System.Windows.Forms.Label();
            this.Lab_PrecioLimon = new System.Windows.Forms.Label();
            this.Lab_digCaramelo = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Lab_DineroIngresado = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.button11 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button12 = new System.Windows.Forms.Button();
            this.label_Tot = new System.Windows.Forms.Label();
            this.lab_TotalPagar = new System.Windows.Forms.Label();
            this.Lab_TipoPago = new System.Windows.Forms.Label();
            this.Lab_SelecProducto = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button_ElegirCookiesCream);
            this.panel1.Controls.Add(this.button_ElegirGalleta);
            this.panel1.Controls.Add(this.button_ElegirCoco);
            this.panel1.Controls.Add(this.button_ElegirCaramelo);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.button_ElegirVinoTinto);
            this.panel1.Controls.Add(this.button_ElegirPistache);
            this.panel1.Controls.Add(this.button_ElegirDulceLeche);
            this.panel1.Controls.Add(this.button_ElegirTaro);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.button_ElegirFresa);
            this.panel1.Controls.Add(this.button_ElegirVainilla);
            this.panel1.Controls.Add(this.button_ElegirChoc);
            this.panel1.Controls.Add(this.button_ElegirLimon);
            this.panel1.Controls.Add(this.Lab_digCookiesCream);
            this.panel1.Controls.Add(this.Lab_digGalleta);
            this.panel1.Controls.Add(this.Lab_digCoco);
            this.panel1.Controls.Add(this.Lab_digCaramel);
            this.panel1.Controls.Add(this.Lab_digVinoTinto);
            this.panel1.Controls.Add(this.Lab_digPistache);
            this.panel1.Controls.Add(this.Lab_digDulceLeche);
            this.panel1.Controls.Add(this.Lab_digTaro);
            this.panel1.Controls.Add(this.Lab_digFresa);
            this.panel1.Controls.Add(this.Lab_digVainilla);
            this.panel1.Controls.Add(this.Lab_digChoc);
            this.panel1.Controls.Add(this.Lab_digLimon);
            this.panel1.Controls.Add(this.Lab_CantLimon);
            this.panel1.Controls.Add(this.Lab_PrecioCookiesCream);
            this.panel1.Controls.Add(this.Lab_PrecioGalleta);
            this.panel1.Controls.Add(this.Lab_PrecioCoco);
            this.panel1.Controls.Add(this.Lab_PrecioCaramelo);
            this.panel1.Controls.Add(this.Lab_PrecioVinoTinto);
            this.panel1.Controls.Add(this.Lab_PrecioPistache);
            this.panel1.Controls.Add(this.Lab_PrecioDulceLeche);
            this.panel1.Controls.Add(this.Lab_PrecioTaro);
            this.panel1.Controls.Add(this.Lab_PrecioFresa);
            this.panel1.Controls.Add(this.Lab_PrecioVainilla);
            this.panel1.Controls.Add(this.Lab_PrecioChoc);
            this.panel1.Controls.Add(this.Lab_PrecioLimon);
            this.panel1.Controls.Add(this.Lab_digCaramelo);
            this.panel1.Controls.Add(this.pictureBox10);
            this.panel1.Controls.Add(this.pictureBox11);
            this.panel1.Controls.Add(this.pictureBox12);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.pictureBox9);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(12, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(647, 645);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button_ElegirCookiesCream
            // 
            this.button_ElegirCookiesCream.Location = new System.Drawing.Point(505, 557);
            this.button_ElegirCookiesCream.Name = "button_ElegirCookiesCream";
            this.button_ElegirCookiesCream.Size = new System.Drawing.Size(92, 36);
            this.button_ElegirCookiesCream.TabIndex = 78;
            this.button_ElegirCookiesCream.Text = "Elegir";
            this.button_ElegirCookiesCream.UseVisualStyleBackColor = true;
            this.button_ElegirCookiesCream.Click += new System.EventHandler(this.button_ElegirCookiesCream_Click);
            // 
            // button_ElegirGalleta
            // 
            this.button_ElegirGalleta.Location = new System.Drawing.Point(353, 557);
            this.button_ElegirGalleta.Name = "button_ElegirGalleta";
            this.button_ElegirGalleta.Size = new System.Drawing.Size(92, 36);
            this.button_ElegirGalleta.TabIndex = 77;
            this.button_ElegirGalleta.Text = "Elegir";
            this.button_ElegirGalleta.UseVisualStyleBackColor = true;
            this.button_ElegirGalleta.Click += new System.EventHandler(this.button_ElegirGalleta_Click);
            // 
            // button_ElegirCoco
            // 
            this.button_ElegirCoco.Location = new System.Drawing.Point(196, 557);
            this.button_ElegirCoco.Name = "button_ElegirCoco";
            this.button_ElegirCoco.Size = new System.Drawing.Size(92, 36);
            this.button_ElegirCoco.TabIndex = 76;
            this.button_ElegirCoco.Text = "Elegir";
            this.button_ElegirCoco.UseVisualStyleBackColor = true;
            this.button_ElegirCoco.Click += new System.EventHandler(this.button_ElegirCoco_Click);
            // 
            // button_ElegirCaramelo
            // 
            this.button_ElegirCaramelo.Location = new System.Drawing.Point(28, 557);
            this.button_ElegirCaramelo.Name = "button_ElegirCaramelo";
            this.button_ElegirCaramelo.Size = new System.Drawing.Size(92, 36);
            this.button_ElegirCaramelo.TabIndex = 75;
            this.button_ElegirCaramelo.Text = "Elegir";
            this.button_ElegirCaramelo.UseVisualStyleBackColor = true;
            this.button_ElegirCaramelo.Click += new System.EventHandler(this.button_ElegirCaramelo_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(21, 557);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 20);
            this.label14.TabIndex = 74;
            // 
            // button_ElegirVinoTinto
            // 
            this.button_ElegirVinoTinto.Location = new System.Drawing.Point(508, 360);
            this.button_ElegirVinoTinto.Name = "button_ElegirVinoTinto";
            this.button_ElegirVinoTinto.Size = new System.Drawing.Size(92, 35);
            this.button_ElegirVinoTinto.TabIndex = 73;
            this.button_ElegirVinoTinto.Text = "Elegir";
            this.button_ElegirVinoTinto.UseVisualStyleBackColor = true;
            this.button_ElegirVinoTinto.Click += new System.EventHandler(this.button_ElegirVinoTinto_Click);
            // 
            // button_ElegirPistache
            // 
            this.button_ElegirPistache.Location = new System.Drawing.Point(349, 360);
            this.button_ElegirPistache.Name = "button_ElegirPistache";
            this.button_ElegirPistache.Size = new System.Drawing.Size(92, 35);
            this.button_ElegirPistache.TabIndex = 72;
            this.button_ElegirPistache.Text = "Elegir";
            this.button_ElegirPistache.UseVisualStyleBackColor = true;
            this.button_ElegirPistache.Click += new System.EventHandler(this.button_ElegirPistache_Click);
            // 
            // button_ElegirDulceLeche
            // 
            this.button_ElegirDulceLeche.Location = new System.Drawing.Point(196, 360);
            this.button_ElegirDulceLeche.Name = "button_ElegirDulceLeche";
            this.button_ElegirDulceLeche.Size = new System.Drawing.Size(92, 35);
            this.button_ElegirDulceLeche.TabIndex = 71;
            this.button_ElegirDulceLeche.Text = "Elegir";
            this.button_ElegirDulceLeche.UseVisualStyleBackColor = true;
            this.button_ElegirDulceLeche.Click += new System.EventHandler(this.button_ElegirDulceLeche_Click);
            // 
            // button_ElegirTaro
            // 
            this.button_ElegirTaro.Location = new System.Drawing.Point(40, 360);
            this.button_ElegirTaro.Name = "button_ElegirTaro";
            this.button_ElegirTaro.Size = new System.Drawing.Size(92, 35);
            this.button_ElegirTaro.TabIndex = 70;
            this.button_ElegirTaro.Text = "Elegir";
            this.button_ElegirTaro.UseVisualStyleBackColor = true;
            this.button_ElegirTaro.Click += new System.EventHandler(this.button_ElegirTaro_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(33, 360);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 20);
            this.label13.TabIndex = 69;
            // 
            // button_ElegirFresa
            // 
            this.button_ElegirFresa.Location = new System.Drawing.Point(505, 176);
            this.button_ElegirFresa.Name = "button_ElegirFresa";
            this.button_ElegirFresa.Size = new System.Drawing.Size(92, 34);
            this.button_ElegirFresa.TabIndex = 68;
            this.button_ElegirFresa.Text = "Elegir";
            this.button_ElegirFresa.UseVisualStyleBackColor = true;
            this.button_ElegirFresa.Click += new System.EventHandler(this.button_ElegirFresa_Click);
            // 
            // button_ElegirVainilla
            // 
            this.button_ElegirVainilla.Location = new System.Drawing.Point(353, 176);
            this.button_ElegirVainilla.Name = "button_ElegirVainilla";
            this.button_ElegirVainilla.Size = new System.Drawing.Size(92, 34);
            this.button_ElegirVainilla.TabIndex = 67;
            this.button_ElegirVainilla.Text = "Elegir";
            this.button_ElegirVainilla.UseVisualStyleBackColor = true;
            this.button_ElegirVainilla.Click += new System.EventHandler(this.button_ElegirVainilla_Click);
            // 
            // button_ElegirChoc
            // 
            this.button_ElegirChoc.Location = new System.Drawing.Point(196, 176);
            this.button_ElegirChoc.Name = "button_ElegirChoc";
            this.button_ElegirChoc.Size = new System.Drawing.Size(92, 34);
            this.button_ElegirChoc.TabIndex = 66;
            this.button_ElegirChoc.Text = "Elegir";
            this.button_ElegirChoc.UseVisualStyleBackColor = true;
            this.button_ElegirChoc.Click += new System.EventHandler(this.button_ElegirChoc_Click);
            // 
            // button_ElegirLimon
            // 
            this.button_ElegirLimon.Location = new System.Drawing.Point(28, 176);
            this.button_ElegirLimon.Name = "button_ElegirLimon";
            this.button_ElegirLimon.Size = new System.Drawing.Size(92, 34);
            this.button_ElegirLimon.TabIndex = 65;
            this.button_ElegirLimon.Text = "Elegir";
            this.button_ElegirLimon.UseVisualStyleBackColor = true;
            this.button_ElegirLimon.Click += new System.EventHandler(this.button12_Click);
            // 
            // Lab_digCookiesCream
            // 
            this.Lab_digCookiesCream.AutoSize = true;
            this.Lab_digCookiesCream.Location = new System.Drawing.Point(485, 405);
            this.Lab_digCookiesCream.Name = "Lab_digCookiesCream";
            this.Lab_digCookiesCream.Size = new System.Drawing.Size(153, 20);
            this.Lab_digCookiesCream.TabIndex = 64;
            this.Lab_digCookiesCream.Text = "Cookies and cream";
            // 
            // Lab_digGalleta
            // 
            this.Lab_digGalleta.AutoSize = true;
            this.Lab_digGalleta.Location = new System.Drawing.Point(371, 405);
            this.Lab_digGalleta.Name = "Lab_digGalleta";
            this.Lab_digGalleta.Size = new System.Drawing.Size(62, 20);
            this.Lab_digGalleta.TabIndex = 63;
            this.Lab_digGalleta.Text = "Galleta";
            // 
            // Lab_digCoco
            // 
            this.Lab_digCoco.AutoSize = true;
            this.Lab_digCoco.Location = new System.Drawing.Point(219, 405);
            this.Lab_digCoco.Name = "Lab_digCoco";
            this.Lab_digCoco.Size = new System.Drawing.Size(48, 20);
            this.Lab_digCoco.TabIndex = 62;
            this.Lab_digCoco.Text = "Coco";
            // 
            // Lab_digCaramel
            // 
            this.Lab_digCaramel.AutoSize = true;
            this.Lab_digCaramel.Location = new System.Drawing.Point(44, 405);
            this.Lab_digCaramel.Name = "Lab_digCaramel";
            this.Lab_digCaramel.Size = new System.Drawing.Size(81, 20);
            this.Lab_digCaramel.TabIndex = 61;
            this.Lab_digCaramel.Text = "Caramelo";
            // 
            // Lab_digVinoTinto
            // 
            this.Lab_digVinoTinto.AutoSize = true;
            this.Lab_digVinoTinto.Location = new System.Drawing.Point(522, 214);
            this.Lab_digVinoTinto.Name = "Lab_digVinoTinto";
            this.Lab_digVinoTinto.Size = new System.Drawing.Size(79, 20);
            this.Lab_digVinoTinto.TabIndex = 60;
            this.Lab_digVinoTinto.Text = "Vino tinto";
            // 
            // Lab_digPistache
            // 
            this.Lab_digPistache.AutoSize = true;
            this.Lab_digPistache.Location = new System.Drawing.Point(367, 214);
            this.Lab_digPistache.Name = "Lab_digPistache";
            this.Lab_digPistache.Size = new System.Drawing.Size(74, 20);
            this.Lab_digPistache.TabIndex = 59;
            this.Lab_digPistache.Text = "Pistache";
            // 
            // Lab_digDulceLeche
            // 
            this.Lab_digDulceLeche.AutoSize = true;
            this.Lab_digDulceLeche.Location = new System.Drawing.Point(183, 213);
            this.Lab_digDulceLeche.Name = "Lab_digDulceLeche";
            this.Lab_digDulceLeche.Size = new System.Drawing.Size(127, 20);
            this.Lab_digDulceLeche.TabIndex = 58;
            this.Lab_digDulceLeche.Text = "Dulce de Leche";
            // 
            // Lab_digTaro
            // 
            this.Lab_digTaro.AutoSize = true;
            this.Lab_digTaro.Location = new System.Drawing.Point(51, 213);
            this.Lab_digTaro.Name = "Lab_digTaro";
            this.Lab_digTaro.Size = new System.Drawing.Size(43, 20);
            this.Lab_digTaro.TabIndex = 57;
            this.Lab_digTaro.Text = "Taro";
            // 
            // Lab_digFresa
            // 
            this.Lab_digFresa.AutoSize = true;
            this.Lab_digFresa.Location = new System.Drawing.Point(526, 43);
            this.Lab_digFresa.Name = "Lab_digFresa";
            this.Lab_digFresa.Size = new System.Drawing.Size(52, 20);
            this.Lab_digFresa.TabIndex = 56;
            this.Lab_digFresa.Text = "Fresa";
            // 
            // Lab_digVainilla
            // 
            this.Lab_digVainilla.AutoSize = true;
            this.Lab_digVainilla.Location = new System.Drawing.Point(371, 42);
            this.Lab_digVainilla.Name = "Lab_digVainilla";
            this.Lab_digVainilla.Size = new System.Drawing.Size(63, 20);
            this.Lab_digVainilla.TabIndex = 55;
            this.Lab_digVainilla.Text = "Vainilla";
            // 
            // Lab_digChoc
            // 
            this.Lab_digChoc.AutoSize = true;
            this.Lab_digChoc.Location = new System.Drawing.Point(214, 42);
            this.Lab_digChoc.Name = "Lab_digChoc";
            this.Lab_digChoc.Size = new System.Drawing.Size(84, 20);
            this.Lab_digChoc.TabIndex = 54;
            this.Lab_digChoc.Text = "Chocolate";
            // 
            // Lab_digLimon
            // 
            this.Lab_digLimon.AutoSize = true;
            this.Lab_digLimon.Location = new System.Drawing.Point(51, 42);
            this.Lab_digLimon.Name = "Lab_digLimon";
            this.Lab_digLimon.Size = new System.Drawing.Size(55, 20);
            this.Lab_digLimon.TabIndex = 53;
            this.Lab_digLimon.Text = "Limón";
            this.Lab_digLimon.Click += new System.EventHandler(this.label1_Click);
            // 
            // Lab_CantLimon
            // 
            this.Lab_CantLimon.AutoSize = true;
            this.Lab_CantLimon.Location = new System.Drawing.Point(21, 176);
            this.Lab_CantLimon.Name = "Lab_CantLimon";
            this.Lab_CantLimon.Size = new System.Drawing.Size(0, 20);
            this.Lab_CantLimon.TabIndex = 41;
            this.Lab_CantLimon.Click += new System.EventHandler(this.Lab_CantLimon_Click);
            // 
            // Lab_PrecioCookiesCream
            // 
            this.Lab_PrecioCookiesCream.AutoSize = true;
            this.Lab_PrecioCookiesCream.Location = new System.Drawing.Point(505, 529);
            this.Lab_PrecioCookiesCream.Name = "Lab_PrecioCookiesCream";
            this.Lab_PrecioCookiesCream.Size = new System.Drawing.Size(76, 20);
            this.Lab_PrecioCookiesCream.TabIndex = 40;
            this.Lab_PrecioCookiesCream.Text = "Precio: 0";
            // 
            // Lab_PrecioGalleta
            // 
            this.Lab_PrecioGalleta.AutoSize = true;
            this.Lab_PrecioGalleta.Location = new System.Drawing.Point(353, 529);
            this.Lab_PrecioGalleta.Name = "Lab_PrecioGalleta";
            this.Lab_PrecioGalleta.Size = new System.Drawing.Size(76, 20);
            this.Lab_PrecioGalleta.TabIndex = 39;
            this.Lab_PrecioGalleta.Text = "Precio: 0";
            // 
            // Lab_PrecioCoco
            // 
            this.Lab_PrecioCoco.AutoSize = true;
            this.Lab_PrecioCoco.Location = new System.Drawing.Point(196, 529);
            this.Lab_PrecioCoco.Name = "Lab_PrecioCoco";
            this.Lab_PrecioCoco.Size = new System.Drawing.Size(76, 20);
            this.Lab_PrecioCoco.TabIndex = 38;
            this.Lab_PrecioCoco.Text = "Precio: 0";
            // 
            // Lab_PrecioCaramelo
            // 
            this.Lab_PrecioCaramelo.AutoSize = true;
            this.Lab_PrecioCaramelo.Location = new System.Drawing.Point(24, 529);
            this.Lab_PrecioCaramelo.Name = "Lab_PrecioCaramelo";
            this.Lab_PrecioCaramelo.Size = new System.Drawing.Size(76, 20);
            this.Lab_PrecioCaramelo.TabIndex = 37;
            this.Lab_PrecioCaramelo.Text = "Precio: 0";
            // 
            // Lab_PrecioVinoTinto
            // 
            this.Lab_PrecioVinoTinto.AutoSize = true;
            this.Lab_PrecioVinoTinto.Location = new System.Drawing.Point(502, 340);
            this.Lab_PrecioVinoTinto.Name = "Lab_PrecioVinoTinto";
            this.Lab_PrecioVinoTinto.Size = new System.Drawing.Size(76, 20);
            this.Lab_PrecioVinoTinto.TabIndex = 36;
            this.Lab_PrecioVinoTinto.Text = "Precio: 0";
            // 
            // Lab_PrecioPistache
            // 
            this.Lab_PrecioPistache.AutoSize = true;
            this.Lab_PrecioPistache.Location = new System.Drawing.Point(350, 340);
            this.Lab_PrecioPistache.Name = "Lab_PrecioPistache";
            this.Lab_PrecioPistache.Size = new System.Drawing.Size(76, 20);
            this.Lab_PrecioPistache.TabIndex = 35;
            this.Lab_PrecioPistache.Text = "Precio: 0";
            // 
            // Lab_PrecioDulceLeche
            // 
            this.Lab_PrecioDulceLeche.AutoSize = true;
            this.Lab_PrecioDulceLeche.Location = new System.Drawing.Point(193, 341);
            this.Lab_PrecioDulceLeche.Name = "Lab_PrecioDulceLeche";
            this.Lab_PrecioDulceLeche.Size = new System.Drawing.Size(76, 20);
            this.Lab_PrecioDulceLeche.TabIndex = 34;
            this.Lab_PrecioDulceLeche.Text = "Precio: 0";
            // 
            // Lab_PrecioTaro
            // 
            this.Lab_PrecioTaro.AutoSize = true;
            this.Lab_PrecioTaro.Location = new System.Drawing.Point(21, 341);
            this.Lab_PrecioTaro.Name = "Lab_PrecioTaro";
            this.Lab_PrecioTaro.Size = new System.Drawing.Size(76, 20);
            this.Lab_PrecioTaro.TabIndex = 33;
            this.Lab_PrecioTaro.Text = "Precio: 0";
            // 
            // Lab_PrecioFresa
            // 
            this.Lab_PrecioFresa.AutoSize = true;
            this.Lab_PrecioFresa.Location = new System.Drawing.Point(502, 155);
            this.Lab_PrecioFresa.Name = "Lab_PrecioFresa";
            this.Lab_PrecioFresa.Size = new System.Drawing.Size(23, 20);
            this.Lab_PrecioFresa.TabIndex = 32;
            this.Lab_PrecioFresa.Text = " 0";
            // 
            // Lab_PrecioVainilla
            // 
            this.Lab_PrecioVainilla.AutoSize = true;
            this.Lab_PrecioVainilla.Location = new System.Drawing.Point(350, 155);
            this.Lab_PrecioVainilla.Name = "Lab_PrecioVainilla";
            this.Lab_PrecioVainilla.Size = new System.Drawing.Size(18, 20);
            this.Lab_PrecioVainilla.TabIndex = 31;
            this.Lab_PrecioVainilla.Text = "0";
            // 
            // Lab_PrecioChoc
            // 
            this.Lab_PrecioChoc.AutoSize = true;
            this.Lab_PrecioChoc.Location = new System.Drawing.Point(193, 155);
            this.Lab_PrecioChoc.Name = "Lab_PrecioChoc";
            this.Lab_PrecioChoc.Size = new System.Drawing.Size(76, 20);
            this.Lab_PrecioChoc.TabIndex = 30;
            this.Lab_PrecioChoc.Text = "Precio: 0";
            // 
            // Lab_PrecioLimon
            // 
            this.Lab_PrecioLimon.AutoSize = true;
            this.Lab_PrecioLimon.Location = new System.Drawing.Point(21, 155);
            this.Lab_PrecioLimon.Name = "Lab_PrecioLimon";
            this.Lab_PrecioLimon.Size = new System.Drawing.Size(76, 20);
            this.Lab_PrecioLimon.TabIndex = 29;
            this.Lab_PrecioLimon.Text = "Precio: 0";
            this.Lab_PrecioLimon.Click += new System.EventHandler(this.Lab_PrecioLimon_Click);
            // 
            // Lab_digCaramelo
            // 
            this.Lab_digCaramelo.AutoSize = true;
            this.Lab_digCaramelo.Location = new System.Drawing.Point(24, 405);
            this.Lab_digCaramelo.Name = "Lab_digCaramelo";
            this.Lab_digCaramelo.Size = new System.Drawing.Size(0, 20);
            this.Lab_digCaramelo.TabIndex = 25;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::Scoop.Properties.Resources.WhatsApp_Image_2024_12_04_at_11_30_08;
            this.pictureBox10.Location = new System.Drawing.Point(497, 424);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(108, 94);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 16;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::Scoop.Properties.Resources.VinoTinto;
            this.pictureBox11.Location = new System.Drawing.Point(497, 241);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(108, 87);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 15;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::Scoop.Properties.Resources.Fresa;
            this.pictureBox12.Location = new System.Drawing.Point(497, 62);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(108, 85);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 14;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Scoop.Properties.Resources.Caramelo;
            this.pictureBox6.Location = new System.Drawing.Point(24, 424);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(108, 94);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 13;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Scoop.Properties.Resources.Taro;
            this.pictureBox7.Location = new System.Drawing.Point(24, 241);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(108, 87);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 12;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Scoop.Properties.Resources.WhatsApp_Image_2024_12_04_at_11_12_15;
            this.pictureBox9.Location = new System.Drawing.Point(24, 62);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(108, 85);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 11;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Scoop.Properties.Resources.Coco;
            this.pictureBox1.Location = new System.Drawing.Point(185, 424);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(108, 94);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Scoop.Properties.Resources.DulceLeche;
            this.pictureBox3.Location = new System.Drawing.Point(186, 241);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(108, 87);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Scoop.Properties.Resources.Chocolate;
            this.pictureBox4.Location = new System.Drawing.Point(185, 62);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(108, 85);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Scoop.Properties.Resources.Lotus;
            this.pictureBox8.Location = new System.Drawing.Point(345, 424);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(108, 94);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 7;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Scoop.Properties.Resources.Pistache;
            this.pictureBox5.Location = new System.Drawing.Point(342, 241);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(108, 87);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Scoop.Properties.Resources.Vainilla;
            this.pictureBox2.Location = new System.Drawing.Point(342, 62);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(108, 85);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Lab_DineroIngresado
            // 
            this.Lab_DineroIngresado.AutoSize = true;
            this.Lab_DineroIngresado.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lab_DineroIngresado.Location = new System.Drawing.Point(842, 409);
            this.Lab_DineroIngresado.Name = "Lab_DineroIngresado";
            this.Lab_DineroIngresado.Size = new System.Drawing.Size(86, 20);
            this.Lab_DineroIngresado.TabIndex = 4;
            this.Lab_DineroIngresado.Text = "Dinero Ing";
            this.Lab_DineroIngresado.Click += new System.EventHandler(this.Lab_DineroIngresado_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button8);
            this.panel3.Controls.Add(this.button7);
            this.panel3.Location = new System.Drawing.Point(713, 156);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(290, 133);
            this.panel3.TabIndex = 6;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(87, 78);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(109, 44);
            this.button8.TabIndex = 1;
            this.button8.Text = "Efectivo";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(87, 18);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(109, 43);
            this.button7.TabIndex = 0;
            this.button7.Text = "Tarjeta";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(757, 327);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 45);
            this.button9.TabIndex = 7;
            this.button9.Text = "Pagar";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::Scoop.Properties.Resources.WhatsApp_Image_2024_12_07_at_11_20_10;
            this.pictureBox13.Location = new System.Drawing.Point(681, 33);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(365, 108);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 8;
            this.pictureBox13.TabStop = false;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(879, 327);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(82, 45);
            this.button11.TabIndex = 9;
            this.button11.Text = " Regresar";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1084, 21);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(442, 473);
            this.dataGridView1.TabIndex = 10;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(1287, 514);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 30);
            this.button12.TabIndex = 11;
            this.button12.Text = "Eliminar";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click_2);
            // 
            // label_Tot
            // 
            this.label_Tot.AutoSize = true;
            this.label_Tot.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Tot.Location = new System.Drawing.Point(677, 444);
            this.label_Tot.Name = "label_Tot";
            this.label_Tot.Size = new System.Drawing.Size(131, 20);
            this.label_Tot.TabIndex = 13;
            this.label_Tot.Text = "Total a pagar:  $";
            // 
            // lab_TotalPagar
            // 
            this.lab_TotalPagar.AutoSize = true;
            this.lab_TotalPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_TotalPagar.Location = new System.Drawing.Point(825, 444);
            this.lab_TotalPagar.Name = "lab_TotalPagar";
            this.lab_TotalPagar.Size = new System.Drawing.Size(94, 20);
            this.lab_TotalPagar.TabIndex = 14;
            this.lab_TotalPagar.Text = "Tot a pagar";
            this.lab_TotalPagar.Click += new System.EventHandler(this.lab_TotalPagar_Click);
            // 
            // Lab_TipoPago
            // 
            this.Lab_TipoPago.AutoSize = true;
            this.Lab_TipoPago.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lab_TipoPago.Location = new System.Drawing.Point(825, 484);
            this.Lab_TipoPago.Name = "Lab_TipoPago";
            this.Lab_TipoPago.Size = new System.Drawing.Size(69, 20);
            this.Lab_TipoPago.TabIndex = 15;
            this.Lab_TipoPago.Text = "Efectivo";
            // 
            // Lab_SelecProducto
            // 
            this.Lab_SelecProducto.AutoSize = true;
            this.Lab_SelecProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lab_SelecProducto.Location = new System.Drawing.Point(880, 521);
            this.Lab_SelecProducto.Name = "Lab_SelecProducto";
            this.Lab_SelecProducto.Size = new System.Drawing.Size(18, 20);
            this.Lab_SelecProducto.TabIndex = 16;
            this.Lab_SelecProducto.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(677, 409);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Dinero Ingresado: $";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(677, 484);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Metodo de pago:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(677, 518);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(184, 20);
            this.label3.TabIndex = 19;
            this.label3.Text = "Producto seleccionado:";
            // 
            // Maquina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1578, 753);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Lab_SelecProducto);
            this.Controls.Add(this.Lab_TipoPago);
            this.Controls.Add(this.lab_TotalPagar);
            this.Controls.Add(this.label_Tot);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.Lab_DineroIngresado);
            this.Controls.Add(this.panel1);
            this.Name = "Maquina";
            this.Text = "Maquina";
            this.Load += new System.EventHandler(this.Maquina_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label Lab_digCaramelo;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label Lab_PrecioCookiesCream;
        private System.Windows.Forms.Label Lab_PrecioGalleta;
        private System.Windows.Forms.Label Lab_PrecioCoco;
        private System.Windows.Forms.Label Lab_PrecioCaramelo;
        private System.Windows.Forms.Label Lab_PrecioVinoTinto;
        private System.Windows.Forms.Label Lab_PrecioPistache;
        private System.Windows.Forms.Label Lab_PrecioDulceLeche;
        private System.Windows.Forms.Label Lab_PrecioTaro;
        private System.Windows.Forms.Label Lab_PrecioFresa;
        private System.Windows.Forms.Label Lab_PrecioVainilla;
        private System.Windows.Forms.Label Lab_PrecioChoc;
        private System.Windows.Forms.Label Lab_PrecioLimon;
        private System.Windows.Forms.Label Lab_CantLimon;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button9;
        public System.Windows.Forms.Label Lab_DineroIngresado;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label Lab_digLimon;
        private System.Windows.Forms.Label Lab_digCookiesCream;
        private System.Windows.Forms.Label Lab_digGalleta;
        private System.Windows.Forms.Label Lab_digCoco;
        private System.Windows.Forms.Label Lab_digCaramel;
        private System.Windows.Forms.Label Lab_digVinoTinto;
        private System.Windows.Forms.Label Lab_digPistache;
        private System.Windows.Forms.Label Lab_digDulceLeche;
        private System.Windows.Forms.Label Lab_digTaro;
        private System.Windows.Forms.Label Lab_digFresa;
        private System.Windows.Forms.Label Lab_digVainilla;
        private System.Windows.Forms.Label Lab_digChoc;
        private System.Windows.Forms.Button button11;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button_ElegirLimon;
        private System.Windows.Forms.Button button_ElegirCookiesCream;
        private System.Windows.Forms.Button button_ElegirGalleta;
        private System.Windows.Forms.Button button_ElegirCoco;
        private System.Windows.Forms.Button button_ElegirCaramelo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button_ElegirVinoTinto;
        private System.Windows.Forms.Button button_ElegirPistache;
        private System.Windows.Forms.Button button_ElegirDulceLeche;
        private System.Windows.Forms.Button button_ElegirTaro;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button_ElegirFresa;
        private System.Windows.Forms.Button button_ElegirVainilla;
        private System.Windows.Forms.Button button_ElegirChoc;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label_Tot;
        public System.Windows.Forms.Label lab_TotalPagar;
        private System.Windows.Forms.Label Lab_TipoPago;
        private System.Windows.Forms.Label Lab_SelecProducto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}